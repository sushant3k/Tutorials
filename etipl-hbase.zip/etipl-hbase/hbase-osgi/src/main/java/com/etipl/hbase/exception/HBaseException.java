/**
 * 
 */
package com.etipl.hbase.exception;

/**
 * @author Sushant
 *
 */
public class HBaseException extends ApplicationException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public HBaseException()
	{
		super();
	}
	public HBaseException(Throwable t)
	{
		super(t);
	}
}
