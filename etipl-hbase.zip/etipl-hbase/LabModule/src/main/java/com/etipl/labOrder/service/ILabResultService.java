package com.etipl.labOrder.service;

import com.etipl.labOrder.model.LabResult;

public interface ILabResultService {

	void storeResults(LabResult lr);
}
