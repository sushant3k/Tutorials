/**
 * 
 */
package com.etipl.labconsumer.service;

/**
 * @author Sushant
 *
 */
public interface ILabConsumer {

	void initiateAllTests();
}
